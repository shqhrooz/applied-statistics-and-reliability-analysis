# ==============================================================================
# سؤال سوم: توزیع نرمال و تبدیل‌ها
# ==============================================================================

# پارامترهای توزیع جامعه
mu <- 182
sigma <- 8

# الف) محاسبه احتمال آماری
prob_a <- pnorm(195, mean = mu, sd = sigma) - pnorm(175, mean = mu, sd = sigma)

print(paste("Probability:", round(prob_a, 5)))
print(paste("Percentage:", round(prob_a * 100, 2), "%"))

# ==============================================================================
# بخش (ب): شبیه‌سازی ۱۲۰۰ نمونه قد و رسم هیستوگرام با منحنی چگالی
# ==============================================================================

library(ggplot2)
# ۱. تعیین دانه تصادف برای تکرارپذیری نتایج
set.seed(1405)

# ۲. شبیه‌سازی ۱۲۰۰ نمونه از توزیع نرمال
n_sim <- 1200
simated_heights <- rnorm(n_sim, mean = mu, sd = sigma)

# ایجاد یک دیتافریم برای رسم با ggplot2
sim_data <- data.frame(Height = simated_heights)

# ۳. محاسبه میانگین و انحراف معیار نمونه‌ای
sample_mean <- mean(simated_heights)
sample_sd <- sd(simated_heights)

print(paste("Sample Mean:", round(sample_mean, 4)))
print(paste("Sample SD:", round(sample_sd, 4)))

# ۴. رسم هیستوگرام و منحنی چگالی برازش‌شده
density_plot <- ggplot(sim_data, aes(x = Height)) +
  # رسم هیستوگرام بر حسب چگالی (y = after_stat(density))
  geom_histogram(aes(y = after_stat(density)), bins = 30,
                 fill = "lightblue", color = "white", alpha = 0.8) +
  # اضافه کردن منحنی چگالی واقعی داده‌های شبیه‌سازی شده
  geom_density(color = "blue", linewidth = 1, linetype = "dashed") +
  # اضافه کردن منحنی تئوریک توزیع نرمال با پارامترهای نمونه
  stat_function(fun = dnorm, args = list(mean = sample_mean, sd = sample_sd),
                color = "purple", linewidth = 1) +
  labs(
    title = "هیستوگرام و منحنی چگالی قد والیبالیست‌های شبیه‌سازی‌شده",
    x = "قد (سانتی‌متر)",
    y = "چگالی"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    text = element_text(family = "Vazir")
  )

# نمایش نمودار
print(density_plot)

# ==============================================================================
# بخش (ج): رسم نمودار برای داده‌های شبیه‌سازی‌شده
# ==============================================================================

qq_plot <- ggplot(sim_data, aes(sample = Height)) +
  stat_qq(color = "purple", alpha = 0.6) +
  stat_qq_line(color = "black", linewidth = 0.8) +
  labs(
    title = "نمودار Q-Q Plot برای داده‌های قد شبیه‌سازی شده",
    x = "چندک‌های تئوریک (Theoretical Quantiles)",
    y = "چندک‌های نمونه‌ای (Sample Quantiles)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    text = element_text(family = "Vazir")
  )

print(qq_plot)

# ==============================================================================
# بخش (د): اعمال تبدیل‌های لگاریتمی و باکس-کاکس و رسم Q-Q Plot
# ==============================================================================

library(dplyr)
library(MASS)

# ۱. تبدیل لگاریتم طبیعی
sim_data <- sim_data |>
  mutate(Log_Height = log(Height))

# ۲. تبدیل باکس-کاکس
bc <- boxcox(Height ~ 1, data = sim_data, plotit = FALSE)
lambda_opt <- bc$x[which.max(bc$y)]
sim_data <- sim_data |>
  mutate(BoxCox_Height = (Height^lambda_opt - 1) / lambda_opt)

# ۳. رسم و ذخیره Q-Q Plot تبدیل لگاریتمی
qq_log <- ggplot(sim_data, aes(sample = Log_Height)) +
  stat_qq(color = "blue", alpha = 0.6) +
  stat_qq_line(color = "black") +
  labs(title = "Q-Q Plot تبدیل لگاریتمی قد", x = "چندک‌های تئوریک", y = "چندک‌های نمونه‌ای") + # nolint
  theme_minimal() + theme(plot.title = element_text(hjust = 0.5, face = "bold"), text = element_text(family = "Vazir")) # nolint

# ۴. رسم و ذخیره Q-Q Plot تبدیل باکس-کاکس
qq_boxcox <- ggplot(sim_data, aes(sample = BoxCox_Height)) +
  stat_qq(color = "darkgreen", alpha = 0.6) +
  stat_qq_line(color = "black") +
  labs(title = "Q-Q Plot تبدیل باکس-کاکس قد", x = "چندک‌های تئوریک", y = "چندک‌های نمونه‌ای") + # nolint
  theme_minimal() + theme(plot.title = element_text(hjust = 0.5, face = "bold"), text = element_text(family = "Vazir")) # nolint

print(qq_log)
print(qq_boxcox)