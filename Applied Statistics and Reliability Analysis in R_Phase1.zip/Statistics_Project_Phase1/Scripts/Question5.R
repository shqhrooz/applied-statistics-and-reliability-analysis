# ==============================================================================
# سؤال پنج - بخش (الف): ساخت شاخص ترکیبی و آزمون فرضیه مقایسه جنسیتی
# ==============================================================================

library(dplyr)

# ۱. بارگذاری داده‌ها (مسیر فایل را بر اساس پروژه خود تنظیم کنید)
data <- read.csv("Data/StudentsPerformance.csv", check.names = FALSE)

# ۲. استانداردسازی نمره‌ها
data <- data |>
  mutate(
    math_z = (`math score` - mean(`math score`)) / sd(`math score`),
    reading_z = (`reading score` - mean(`reading score`)) / sd(`reading score`),
    writing_z = (`writing score` - mean(`writing score`)) / sd(`writing score`)
  )

# ۳. ساخت شاخص ترکیبی (میانگین ۳ نمره استاندارد شده در هر ردیف)
data <- data |>
  mutate(composite_index = (math_z + reading_z + writing_z) / 3)

# ۴. بررسی فرضیه نرمال بودن شاخص ترکیبی (آزمون شاپیرو-ویلک)
shapiro_all <- shapiro.test(data$composite_index)
shapiro_female <- shapiro.test(data$composite_index[data$gender == "female"])
shapiro_male <- shapiro.test(data$composite_index[data$gender == "male"])

print("--- نتایج آزمون نرمال بودن (Shapiro-Wilk) ---")
print(paste("کل داده‌ها: p-value =", format(shapiro_all$p.value, scientific = TRUE))) # nolint
print(paste("دانش‌آموزان زن: p-value =", format(shapiro_female$p.value, scientific = TRUE))) # nolint
print(paste("دانش‌آموزان مرد: p-value =", format(shapiro_male$p.value, scientific = TRUE))) # nolint

# ۵. محاسبه شاخص‌های توصیفی شاخص ترکیبی به تفکیک جنسیت
gender_summary <- data |>
  group_by(gender) |>
  summarise(
    Count = n(),
    Mean_Composite = round(mean(composite_index), 4),
    SD_Composite = round(sd(composite_index), 4)
  )

print("--- شاخص‌های توصیفی شاخص ترکیبی به تفکیک جنسیت ---")
print(gender_summary)

# ۶. اجرای آزمون‌های آماری مقایسه دو گروه
# الف) آزمون پارامتریک تی با فرض واریانس نابرابر به دلیل حجم نمونه بزرگ (N=1000) # nolint
t_test_res <- t.test(composite_index ~ gender, data = data, var.equal = FALSE)

# ب) آزمون ناپارامتریک من-ویتنی به دلیل رد فرض نرمال بودن در شاخص ترکیبی # nolint
mwu_test_res <- wilcox.test(composite_index ~ gender, data = data)

print("--- نتایج آزمون‌های مقایسه میانگین/میانه بین دو جنسیت ---")
print(t_test_res)
print(mwu_test_res)

# ==============================================================================
# سؤال پنج - بخش (ج): رسم نمودار پراکندگی و تحلیل همبستگی خواندن و نوشتن
# ==============================================================================

# ==============================================================================
# سؤال پنج - بخش (ج): رسم نمودار پراکندگی و تحلیل همبستگی خواندن و نوشتن 
# ==============================================================================

library(ggplot2)

#بارگذاری داده‌ها
if(!exists("data")) {  # nolint
  data <- read.csv("Data/StudentsPerformance.csv", check.names = FALSE)
}
#(Scatter Plot)
#ساخت نمودار پراکندگی  با خط رگرسیون
scatter_plot <- ggplot(data, aes(x = `reading score`, y = `writing score`)) +
  geom_point(color = "#1f77b4", alpha = 0.5, size = 2) +
  geom_smooth(method = "lm", color = "#d62728", se = TRUE, size = 1.2) +
  labs(
    title = "نمودار پراکندگی ارتباط بین نمره خواندن و نمره نوشتن",
    x = "نمره خواندن (Reading Score)",
    y = "نمره نوشتن (Writing Score)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 13),
    axis.title = element_text(face = "bold", size = 11)
  )
print(scatter_plot)

#اجرای آزمون‌های همبستگی پیرسون و اسپیرمن
pearson_res <- cor.test(data$`reading score`, data$`writing score`, method = "pearson") # nolint
spearman_res <- cor.test(data$`reading score`, data$`writing score`, method = "spearman") # nolint

print(pearson_res)
print(spearman_res)