# ==============================================================================
# سؤال دوم: نمونه‌گیری پذیرش و منحنی OC
# ==============================================================================

library(ggplot2)
library(dplyr)

# پارامترهای مسئله
n <- 60  # حجم نمونه
c <- 3   # آستانه پذیرش (دسته زمانی پذیرفته می‌شود که معیوب‌ها =< 3 باشد)

#مقادیر نرخ واقعی معیوب طبق صورت سوال
p_values <- c(0.01, 0.02, 0.03, 0.05, 0.10, 0.15, 0.20)

#استفاده از توزیع دوجمله‌ای و محاسبه‌ی احتمالات پذیرش به ازای هر مقدار
oc_data <- data.frame(p = p_values) |>
  mutate(
    P_accept = pbinom(c, size = n, prob = p)
  )
print(oc_data)

#رسم منحنی مشخصه‌ی عملکرد
oc_plot <- ggplot(oc_data, aes(x = p, y = P_accept)) +
  geom_line(color = "black", linewidth = 1) +
  geom_point(color = "purple", size = 3) +
  scale_x_continuous(labels = scales::percent, breaks = p_values) +
  scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.1)) +
  labs(
    title = "OC Curve (منحنی مشخصه عملکرد)",
    x = "نرخ واقعی معیوب در جامعه (p)",
    y = "احتمال پذیرش دسته (Pa)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    text = element_text(family = "Vazir")
  )
print(oc_plot)