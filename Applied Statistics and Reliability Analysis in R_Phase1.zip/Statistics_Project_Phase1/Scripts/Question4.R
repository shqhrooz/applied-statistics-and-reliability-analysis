# ==============================================================================
# سؤال چهارم: مقایسه دو گروه با آزمون t ولش
# ==============================================================================

library(dplyr)

# ۱. بارگذاری داده‌ها (مسیر فایل را بر اساس پروژه خود تنظیم کنید)
data <- read.csv("Data/StudentsPerformance.csv", check.names = FALSE)

# نمایش نام ستون‌ها برای اطمینان
print(colnames(data))


# بررسی پیش‌فرض‌های آزمون: آزمون نرمال بودن شاپیرو-ویلک
shapiro_completed <- shapiro.test(data$`math score`[data$`test preparation course` == "completed"]) # nolint
shapiro_none <- shapiro.test(data$`math score`[data$`test preparation course` == "none"]) # nolint

print(paste("گروه دوره دیده (completed): p-value =", format(shapiro_completed$p.value, scientific = TRUE))) # nolint
print(paste("گروه دوره ندیده (none): p-value =", format(shapiro_none$p.value, scientific = TRUE))) # nolint

# ۲. اجرای آزمون تی ولش با فرض نابرابری واریانس‌ها 
welch_test <- t.test(`math score` ~ `test preparation course`,
                     data = data,
                     var.equal = FALSE)

# نمایش خلاصه خروجی آزمون
print(welch_test)

# ==============================================================================
# بخش (ب): محاسبه شاخص‌های توصیفی و استخراج مشخصات آزمون
# ==============================================================================

# ۱. محاسبه میانگین و انحراف معیار به تفکیک گروه
summary_stats <- data |>
  group_by(`test preparation course`) |>
  summarise(
    Count = n(),
    Mean_Score = round(mean(`math score`), 4),
    SD_Score = round(sd(`math score`), 4)
  )

print(summary_stats)

t_value <- welch_test$statistic
p_value <- welch_test$p.value

print(paste("آماره آزمون (t):", round(t_value, 4)))
print(paste("مقدار p-value:", format(p_value, scientific = TRUE)))

# ==============================================================================
# بخش (د): محاسبه اندازه اثر و تخمین حداقل حجم نمونه مورد نیاز 
# ==============================================================================

if(!require(pwr)) install.packages("pwr") # nolint
library(pwr)

# ۱. استخراج اطلاعات آماری دو گروه
n1 <- 358
n2 <- 642
mean1 <- 69.6955
mean2 <- 64.0779
sd1 <- 14.4447
sd2 <- 15.1924

# ۲. محاسبه انحراف معیار ترکیب شده (Pooled Standard Deviation)
sd_pooled <- sqrt(((n1 - 1) * sd1^2 + (n2 - 1) * sd2^2) / (n1 + n2 - 2))

# ۳. محاسبه اندازه اثر کوهن (Cohen's d)
cohens_d <- (mean1 - mean2) / sd_pooled
print(paste("اندازه اثر کوهن (Cohen's d):", round(cohens_d, 4)))

# ۴. تخمین حداقل حجم نمونه برای هر گروه با توان 85 درصدی
# الف) با سطح معنی‌داری 0.01 (مطابق بخش ب)
sample_size_01 <- pwr.t.test(d = cohens_d,
                             sig.level = 0.01,
                             power = 0.85,
                             type = "two.sample",
                             alternative = "two.sided")

# ب) با سطح معنی‌داری متداول 0.05 (جهت مقایسه و گزارش کامل‌تر)
sample_size_05 <- pwr.t.test(d = cohens_d,
                             sig.level = 0.05,
                             power = 0.85,
                             type = "two.sample",
                             alternative = "two.sided")

print("--- حداقل حجم نمونه مورد نیاز برای هر گروه ---")
print(paste("با سطح معنی‌داری 0.01:", ceiling(sample_size_01$n)))
print(paste("با سطح معنی‌داری 0.05:", ceiling(sample_size_05$n)))