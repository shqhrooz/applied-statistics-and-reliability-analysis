# -------------------------
# Question 1
# Engineering Statistics Project
# -------------------------

# Load libraries
library(readr)
library(dplyr)
library(ggplot2)

# Read dataset
sleep <- read_csv("Data/Sleep_health_and_lifestyle_dataset.csv")

# Explore data
dim(sleep)
names(sleep)
str(sleep)
summary(sleep)

# Basic statistics
mean(sleep$`Daily Steps`)
sd(sleep$`Daily Steps`)
table(sleep$Gender)

# Grouped summary
sleep |>
  group_by(`Sleep Disorder`) |>
  summarise(
    mean_sleep = mean(`Sleep Duration`),
    mean_stress = mean(`Stress Level`)
  )
# A
# First plot (Sleep Duration By Sleep Disorder)
ggplot(sleep,
       aes(x = `Sleep Disorder`,
           y = `Sleep Duration`)) +
  geom_boxplot() +
  labs(
    title = "Sleep Duration by Sleep Disorder",
    x = "Sleep Disorder",
    y = "Sleep Duration (hours)"
  )

#Second Plot Relationship Between Stress Level and Sleep Duration
ggplot(
  sleep,
  aes(
    x = `Stress Level`,
    y = `Sleep Duration`
  )
) +
  geom_jitter(width = 0.15, height = 0.05, alpha = 0.7) +
  labs(
    title = "Relationship Between Stress Level and Sleep Duration",
    x = "Stress Level",
    y = "Sleep Duration (hours)"
  )

#Third Plot:Stress Level vs Physical Activity Level
ggplot(sleep,
       aes(x = `Physical Activity Level`,
           y = `Stress Level`)) +
  geom_jitter(width = 1,
              height = 0.15,
              alpha = 0.6,
              color = "steelblue") +
  geom_smooth(method = "lm",
              se = FALSE,
              color = "red") +
  labs(
    title = "Stress Level vs Physical Activity Level",
    x = "Physical Activity Level",
    y = "Stress Level"
  )

#Fourth Plot: Daily Steps by BMI Category
ggplot(sleep,
       aes(x = `BMI Category`,
           y = `Daily Steps`)) +
  geom_boxplot(fill = "lightgreen") +
  labs(
    title = "Daily Steps by BMI Category",
    x = "BMI Category",
    y = "Daily Steps"
  ) +
  theme_minimal()

# ==============================================================================
# بخش (ب) بررسی اثر جنسیت بر سطح استرس
# ==============================================================================

#شاخص های میانگین و انحراف معیار جامعه در زیر مشاهده می‌شود
sleep |>
  group_by(Gender) |>
  summarise(
    n = n(),
    mean = mean(`Stress Level`),
    sd = sd(`Stress Level`)
  )
# بررسی نرمال بودن
shapiro.test(
  sleep$`Stress Level`[
    sleep$Gender == "Male"
  ]
)
shapiro.test(
  sleep$`Stress Level`[
    sleep$Gender == "Female"
  ]
)

#تست بررسی برابری واریانس‌ها
var.test(
  `Stress Level` ~ Gender,
  data = sleep
)

# Mann–Whitney Test
wilcox.test(
  `Stress Level` ~ Gender,
  data = sleep,
  exact = FALSE
)

#میانگین و میانه هر گروه
sleep  |>
  group_by(Gender) |>
  summarise(
    n = n(),
    mean_stress = mean(`Stress Level`),
    median_stress = median(`Stress Level`),
    sd_stress = sd(`Stress Level`)
  )

# ==============================================================================
# بخش (ج): بررسی ادعای محقق در مورد سطح فعالیت بدنی و تعداد قدم‌های روزانه
# ==============================================================================
library(dplyr)

#ایجاد متغیر دسته‌ای جدید بر اساس ادعای محقق
sleep_activity <- sleep |>
  mutate(
    Activity_Group = case_when(
      `Physical Activity Level` >= 60 ~ "High",
      `Physical Activity Level` < 40  ~ "Low",
      TRUE ~ NA_character_ # حذف افرادی که بین ۴۰ و ۶۰ هستند طبق صورت سوال
    )
  ) |>
  filter(!is.na(Activity_Group))

#آمار توصیفی گروه‌ها
activity_summary <- sleep_activity |>
  group_by(Activity_Group) |>
  summarise(
    n = n(),
    mean_steps = mean(`Daily Steps`),
    median_steps = median(`Daily Steps`),
    sd_steps = sd(`Daily Steps`)
  )
print(activity_summary)

#آزمون نرمال بودن برای هر گروه
shapiro_high <- shapiro.test(sleep_activity$`Daily Steps`[sleep_activity$Activity_Group == "High"]) # nolint
shapiro_low  <- shapiro.test(sleep_activity$`Daily Steps`[sleep_activity$Activity_Group == "Low"]) # nolint

print(shapiro_high)
print(shapiro_low)

#آزمون برابری واریانس‌ها (در صورت نرمال بودن داده‌ها)
var_test_activity <- var.test(`Daily Steps` ~ Activity_Group, data = sleep_activity) # nolint
print(var_test_activity)

# آزمون ناپارامتری ویلکاکسون (مان-ویتنی)
wilcox_activity <- wilcox.test(
  `Daily Steps` ~ Activity_Group,
  data = sleep_activity,
  alternative = "greater",
  exact = FALSE
)
print(wilcox_activity)

# ==============================================================================
# بخش (د): مقایسه میانگین مدت خواب افراد بدون اختلال و افراد دارای اختلال خواب
# ==============================================================================

# ۱. ایجاد متغیر دوحالته (بدون اختلال در برابر دارای اختلال)
sleep_disorder_compare <- sleep |>
  mutate(
    Disorder_Status = ifelse(`Sleep Disorder` == "None", "No Disorder", "Has Disorder") #nolint
  )
print(sleep_disorder_compare)

# ۲. آمار توصیفی مدت زمان خواب در دو گروه
sleep_summary <- sleep_disorder_compare |>
  group_by(Disorder_Status) |>
  summarise(
    n = n(),
    mean_sleep = mean(`Sleep Duration`),
    median_sleep = median(`Sleep Duration`),
    sd_sleep = sd(`Sleep Duration`)
  )
print(sleep_summary)

# ۳. آزمون نرمال بودن برای هر دو گروه
shapiro_no_disorder  <- shapiro.test(sleep_disorder_compare$`Sleep Duration`[sleep_disorder_compare$Disorder_Status == "No Disorder"]) # nolint
shapiro_has_disorder <- shapiro.test(sleep_disorder_compare$`Sleep Duration`[sleep_disorder_compare$Disorder_Status == "Has Disorder"]) # nolint

print(shapiro_no_disorder)
print(shapiro_has_disorder)

# ۴. بررسی فرض برابری واریانس‌ها
var_test_sleep <- var.test(`Sleep Duration` ~ Disorder_Status, data = sleep_disorder_compare) # nolint
print(var_test_sleep)

#آزمون ناپارامتری ویلکاکسون  - آزمون دو دامنه
wilcox_sleep <- wilcox.test(`Sleep Duration` ~ Disorder_Status, data = sleep_disorder_compare, exact = FALSE) # nolint
print(wilcox_sleep)

# ==============================================================================
# بخش (ه): بررسی ادعای متخصص تغذیه در مورد مردان (استرس و سطح فعالیت بدنی)
# ==============================================================================

# ۱. فیلتر کردن داده‌ها برای مردان و ایجاد دو گروه استرس بالا و پایین
male_stress_compare <- sleep |>
  filter(Gender == "Male") |>
  mutate(
    Stress_Group = case_when(
      `Stress Level` == 3 ~ "Low Stress",
      `Stress Level` >= 7 ~ "High Stress",
      TRUE ~ NA_character_ # حذف سایر سطوح استرس که مد نظر ادعا نیستند
    )
  ) |>
  filter(!is.na(Stress_Group))

# ۲. آمار توصیفی سطح فعالیت بدنی در دو گروه
male_summary <- male_stress_compare |>
  group_by(Stress_Group) |>
  summarise(
    n = n(),
    mean_activity = mean(`Physical Activity Level`),
    median_activity = median(`Physical Activity Level`),
    sd_activity = sd(`Physical Activity Level`)
  )
print(male_summary)

# ۳. آزمون نرمال بودن برای هر گروه
shapiro_male_low  <- shapiro.test(male_stress_compare$`Physical Activity Level`[male_stress_compare$Stress_Group == "Low Stress"]) # nolint
shapiro_male_high <- shapiro.test(male_stress_compare$`Physical Activity Level`[male_stress_compare$Stress_Group == "High Stress"]) # nolint

print(shapiro_male_low)
print(shapiro_male_high)

# ۴. بررسی فرض برابری واریانس‌ها 
var_test_male <- var.test(`Physical Activity Level` ~ Stress_Group, data = male_stress_compare) # nolint
print(var_test_male)


#آزمون ناپارامتری ویلکاکسون
wilcox_male <- wilcox.test(
  `Physical Activity Level` ~ Stress_Group,
  data = male_stress_compare,
  alternative = "less",
  exact = FALSE
)
print(wilcox_male)
