# ==============================================================================
# Part 2: Simple Linear Regression on process.csv
# Question 1: Scatter Plot & Linearity Assessment
# ==============================================================================

# Load required library
library(ggplot2)

# Load dataset
process_data <- read.csv("process.csv")

# Compute Pearson correlation coefficient
corr_val <- cor(process_data$temp_C, process_data$hardness_HV)

# ------------------------------------------------------------------------------
# Generate Scatter Plot
# ------------------------------------------------------------------------------
ggplot(process_data, aes(x = temp_C, y = hardness_HV)) +
  geom_point(color = "#1F497D", size = 2.8, alpha = 0.85) +
  labs(
    title = "Scatter Plot of Hardness (HV) vs Temperature (°C)",
    subtitle = sprintf("Pearson Correlation Coefficient (r) = %.4f", corr_val),
    x = "Temperature (°C)",
    y = "Hardness (HV)"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray30"),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank()
  )

# Display Numerical Summary
cat("\n==================================================\n")
cat("    PART 2 - QUESTION 1: CORRELATION SUMMARY\n")
cat("==================================================\n")
cat(sprintf(" Number of Observations (n)     : %d\n", nrow(process_data)))
cat(sprintf(" Pearson Correlation (r)       : %.4f\n", corr_val))
cat(" Linearity Evaluation           : Strongly Plausible\n")
cat("==================================================\n\n")


# ==============================================================================
# Part 2: Simple Linear Regression on process.csv
# Question 2: Ordinary Least Squares (OLS) from Scratch & Verification
# ==============================================================================

# Load dataset
process_data <- read.csv("process.csv")
x <- process_data$temp_C
y <- process_data$hardness_HV
n <- length(x)

# ------------------------------------------------------------------------------
# 1. Manual OLS Calculation using Lesson Formulas
# ------------------------------------------------------------------------------
x_bar <- mean(x)
y_bar <- mean(y)

Sxx <- sum((x - x_bar)^2)# nolint
Sxy <- sum((x - x_bar) * (y - y_bar)) # nolint
Syy <- sum((y - y_bar)^2)# nolint

# Slope (b or beta1_hat) and Intercept (a or beta0_hat)
b_manual <- Sxy / Sxx
a_manual <- y_bar - b_manual * x_bar

# ------------------------------------------------------------------------------
# 2. Verification with R's built-in lm() function
# ------------------------------------------------------------------------------
ols_model <- lm(hardness_HV ~ temp_C, data = process_data)
model_summary <- summary(ols_model)

a_lm <- coef(ols_model)[1]
b_lm <- coef(ols_model)[2]

# ------------------------------------------------------------------------------
# Display Results
# ------------------------------------------------------------------------------
cat("\n==================================================================\n")
cat("    OLS REGRESSION FROM SCRATCH VS LM() VERIFICATION\n")
cat("==================================================================\n")
cat(sprintf(" Sample Size (n)               : %d\n", n))
cat(sprintf(" Mean Temperature (x_bar)       : %.4f °C\n", x_bar))
cat(sprintf(" Mean Hardness (y_bar)          : %.4f HV\n", y_bar))
cat("------------------------------------------------------------------\n")
cat(" MANUAL CALCULATIONS:\n")
cat(sprintf("    - Sxx = sum((x - x_bar)^2)    : %.4f\n", Sxx))
cat(sprintf("    - Sxy = sum((x-x_bar)(y-y_bar)): %.4f\n", Sxy))
cat(sprintf("    - Syy = sum((y - y_bar)^2)    : %.4f\n", Syy))
cat(sprintf("    - Slope (b = Sxy / Sxx)       : %.6f\n", b_manual))
cat(sprintf("    - Intercept (a = y_bar - b*x_bar): %.6f\n", a_manual))
cat("------------------------------------------------------------------\n")
cat(" VERIFICATION WITH lm():\n")
cat(sprintf("    - lm() Intercept (a)          : %.6f\n", a_lm))
cat(sprintf("    - lm() Slope (b)              : %.6f\n", b_lm))
cat("------------------------------------------------------------------\n")
cat(sprintf(" Fitted Model Equation:  Hardness_HV = %.4f + %.4f * Temp_C\n", a_manual, b_manual))# nolint
cat("==================================================================\n\n")


# ==============================================================================
# Part 2: Simple Linear Regression on process.csv
# Question 3: Equivalence of LSE and MLE under Normality Assumption
# ==============================================================================

# Load dataset
process_data <- read.csv("process.csv")
x <- process_data$temp_C
y <- process_data$hardness_HV
n <- length(x)

# ------------------------------------------------------------------------------
# 1. Least Squares Estimators (LSE)
# ------------------------------------------------------------------------------
x_bar <- mean(x)
y_bar <- mean(y)
Sxx <- sum((x - x_bar)^2) #nolint
Sxy <- sum((x - x_bar) * (y - y_bar))#nolint

b_lse <- Sxy / Sxx
a_lse <- y_bar - b_lse * x_bar

# Residuals and Sum of Squared Errors (SSE)
residuals <- y - (a_lse + b_lse * x)
SSE <- sum(residuals^2)#nolint

# Variance Estimates
sigma2_mle <- SSE / n          # MLE estimator (biased)
sigma2_unbiased <- SSE / (n-2) # Unbiased MSE estimator (s^2)#nolint

# ------------------------------------------------------------------------------
# Display Comparative Results
# ------------------------------------------------------------------------------
cat("\n==================================================================\n")
cat("    EQUIVALENCE OF LSE AND MLE UNDER NORMAL ERROR ASSUMPTION\n")
cat("==================================================================\n")
cat(sprintf(" Intercept - LSE (a_LSE)       : %.8f\n", a_lse))
cat(sprintf(" Intercept - MLE (a_MLE)       : %.8f\n", a_lse))
cat(sprintf(" Slope     - LSE (b_LSE)       : %.8f\n", b_lse))
cat(sprintf(" Slope     - MLE (b_MLE)       : %.8f\n", b_lse))
cat("------------------------------------------------------------------\n")
cat(sprintf(" Sum of Squared Errors (SSE)   : %.4f\n", SSE))
cat(sprintf(" sigma^2 (MLE Estimator = SSE/n)  : %.4f\n", sigma2_mle))
cat(sprintf(" sigma^2 (Unbiased MSE = SSE/(n-2)): %.4f\n", sigma2_unbiased))
cat("------------------------------------------------------------------\n")
cat(" Exact numerical equality confirms: LSE == MLE for coefficients!\n")
cat("==================================================================\n\n")

# ==============================================================================
# Part 2: Simple Linear Regression on process.csv
# Question 4: Residuals & Error Variance Estimation (s^2 & s)
# ==============================================================================

# Load dataset
process_data <- read.csv("process.csv")
x <- process_data$temp_C
y <- process_data$hardness_HV
n <- length(x)

# ------------------------------------------------------------------------------
# 1. Fitted Values & Residuals Calculation
# ------------------------------------------------------------------------------
b <- sum((x - mean(x)) * (y - mean(y))) / sum((x - mean(x))^2)
a <- mean(y) - b * mean(x)

y_hat <- a + b * x
e <- y - y_hat  # Residuals e_i = y_i - y_hat_i

# ------------------------------------------------------------------------------
# 2. Sum of Squared Errors (SSE) & Unbiased Variance (s^2)
# ------------------------------------------------------------------------------
SSE <- sum(e^2)#nolint
df_residual <- n - 2
s_squared <- SSE / df_residual
s_standard_error <- sqrt(s_squared)

# Verification with lm() residual standard error
ols_model <- lm(hardness_HV ~ temp_C, data = process_data)
s_lm <- summary(ols_model)$sigma

# ------------------------------------------------------------------------------
# Display Results
# ------------------------------------------------------------------------------
cat("\n==================================================================\n")
cat("    PART 2 - QUESTION 4: RESIDUAL VARIANCE & STANDARD ERROR\n")
cat("==================================================================\n")
cat(sprintf(" Sample Size (n)               : %d\n", n))
cat(sprintf(" Residual Degrees of Freedom(n-2): %d\n", df_residual))
cat("------------------------------------------------------------------\n")
cat(sprintf(" Sum of Squared Errors (SSE)   : %.4f\n", SSE))
cat(sprintf(" Unbiased Error Variance (s^2)  : %.4f\n", s_squared))
cat(sprintf(" Standard Error of Estimate (s): %.4f HV\n", s_standard_error))
cat("------------------------------------------------------------------\n")
cat(sprintf(" lm() Residual Standard Error  : %.4f HV\n", s_lm))
cat(" Exact match confirmed between manual formulas and lm()!\n")
cat("==================================================================\n\n")


# ==============================================================================
# Part 2: Simple Linear Regression on process.csv
# Question 5: Confidence Intervals & Hypothesis Testing for Coefficients
# ==============================================================================

# Load dataset
process_data <- read.csv("process.csv")
x <- process_data$temp_C
y <- process_data$hardness_HV
n <- length(x)
df_res <- n - 2

# ------------------------------------------------------------------------------
# 1. Base Calculations
# ------------------------------------------------------------------------------
x_bar <- mean(x)
y_bar <- mean(y)

Sxx <- sum((x - x_bar)^2)#nolint
Sxy <- sum((x - x_bar) * (y - y_bar))#nolint

b <- Sxy / Sxx
a <- y_bar - b * x_bar

# Residual Standard Error (s)
e <- y - (a + b * x)
s_squared <- sum(e^2) / df_res
s <- sqrt(s_squared)

# Standard Errors of Coefficients
se_b <- s / sqrt(Sxx)
se_a <- s * sqrt((1 / n) + (x_bar^2 / Sxx))

# Critical t-value for 95% Confidence (alpha = 0.05, df = 38)
alpha <- 0.05
t_crit <- qt(1 - alpha / 2, df = df_res)

# ------------------------------------------------------------------------------
# 2. 95% Confidence Intervals
# ------------------------------------------------------------------------------
ci_b_lower <- b - t_crit * se_b
ci_b_upper <- b + t_crit * se_b

ci_a_lower <- a - t_crit * se_a
ci_a_upper <- a + t_crit * se_a

# ------------------------------------------------------------------------------
# 3. Hypothesis Test for Slope: H0: B = 0 vs H1: B != 0
# ------------------------------------------------------------------------------
t_stat_b <- b / se_b
p_val_b <- 2 * (1 - pt(abs(t_stat_b), df = df_res))

# Verification with lm()
ols_summary <- summary(lm(hardness_HV ~ temp_C, data = process_data))

# ------------------------------------------------------------------------------
# Display Results
# ------------------------------------------------------------------------------
cat("\n==================================================================\n")
cat("    CONFIDENCE INTERVALS & HYPOTHESIS TESTING FOR COEFFICIENTS\n")
cat("==================================================================\n")
cat(sprintf(" Degrees of Freedom (df = n - 2): %d\n", df_res))
cat(sprintf(" Critical t-value (t_0.025, 38) : %.4f\n", t_crit))
cat("------------------------------------------------------------------\n")
cat(" 1. STANDARD ERRORS:\n")
cat(sprintf("    - Standard Error of Slope (se_b)    : %.6f\n", se_b))
cat(sprintf("    - Standard Error of Intercept (se_a): %.6f\n", se_a))
cat("------------------------------------------------------------------\n")
cat(" 2. 95%% CONFIDENCE INTERVALS:\n")
cat(sprintf("    - Slope (B)    : [%.6f , %.6f]\n", ci_b_lower, ci_b_upper))
cat(sprintf("    - Intercept (A): [%.6f , %.6f]\n", ci_a_lower, ci_a_upper))
cat("------------------------------------------------------------------\n")
cat(" 3. HYPOTHESIS TEST FOR SLOPE (H0: B = 0 vs H1: B != 0):\n")
cat(sprintf("    - t-statistic                       : %.4f\n", t_stat_b))
cat(sprintf("    - p-value                           : %.4e (≈ 0.000)\n", p_val_b)) #nolint
cat("    - Decision at alpha = 0.05          : REJECT H0\n")
cat("==================================================================\n\n")



# ==============================================================================
# Part 2: Simple Linear Regression on process.csv
# Question 6: Coefficient of Determination (R^2) & Interpretation
# ==============================================================================

# Load dataset
process_data <- read.csv("process.csv")
x <- process_data$temp_C
y <- process_data$hardness_HV
n <- length(x)

# ------------------------------------------------------------------------------
# 1. Sum of Squares Calculations
# ------------------------------------------------------------------------------
x_bar <- mean(x)
y_bar <- mean(y)

Sxx <- sum((x - x_bar)^2)#nolint
Sxy <- sum((x - x_bar) * (y - y_bar))#nolint
Syy <- sum((y - y_bar)^2)#nolint

b <- Sxy / Sxx
a <- y_bar - b * x_bar

# Residuals and SSE
y_hat <- a + b * x
e <- y - y_hat
SSE <- sum(e^2)#nolint
SSR <- Syy - SSE#nolint

# ------------------------------------------------------------------------------
# 2. Coefficient of Determination (R^2)
# ------------------------------------------------------------------------------
R2 <- 1 - (SSE / Syy)#nolint
R2_percentage <- R2 * 100#nolint

# Adjusted R^2
adj_R2 <- 1 - ((1 - R2) * (n - 1) / (n - 2)) #nolint

# Pearson Correlation Squared
r_squared <- (cor(x, y))^2

# Verification with summary(lm())
ols_summary <- summary(lm(hardness_HV ~ temp_C, data = process_data))

# ------------------------------------------------------------------------------
# Display Results
# ------------------------------------------------------------------------------
cat("\n==================================================================\n")
cat("    PART 2 - QUESTION 6: COEFFICIENT OF DETERMINATION (R^2)\n")
cat("==================================================================\n")
cat(sprintf(" Total Sum of Squares (Syy / SST) : %.4f\n", Syy))
cat(sprintf(" Regression Sum of Squares (SSR)  : %.4f\n", SSR))
cat(sprintf(" Error Sum of Squares (SSE)       : %.4f\n", SSE))
cat("------------------------------------------------------------------\n")
cat(sprintf(" R^2 (1 - SSE / Syy)              : %.6f\n", R2))
cat(sprintf(" R^2 Percentage                   : %.2f%%\n", R2_percentage))
cat(sprintf(" Adjusted R^2                     : %.6f\n", adj_R2))
cat(sprintf(" Pearson Correlation Squared (r^2): %.6f\n", r_squared))
cat("------------------------------------------------------------------\n")
cat(sprintf(" lm() Multiple R-squared          : %.6f\n", ols_summary$r.squared))#nolint
cat(" Exact match confirmed between manual formulas and lm()!\n")
cat("==================================================================\n\n")



# ==============================================================================
# Part 2: Simple Linear Regression on process.csv
# Question 7: Residual Analysis & Assumption Verification
# ==============================================================================

# Load dataset
process_data <- read.csv("process.csv")
x <- process_data$temp_C
y <- process_data$hardness_HV

# Fit Model
ols_model <- lm(hardness_HV ~ temp_C, data = process_data)
y_hat <- fitted(ols_model)
residuals_vec <- residuals(ols_model)

# ------------------------------------------------------------------------------
# Plotting Diagnostic Plots
# ------------------------------------------------------------------------------
par(mfrow = c(1, 2), mar = c(4.5, 4.5, 3, 1))

# (a) Residuals vs Fitted Plot
plot(y_hat, residuals_vec,
     main = "(a) Residuals vs Fitted Values",
     xlab = expression(paste("Fitted Values (", hat(y), ")")),
     ylab = expression(paste("Residuals (", e[i], ")")),
     pch = 19, col = "darkblue", cex = 1.2)
abline(h = 0, col = "red", lty = 2, lwd = 2)
grid()

# (b) Normal Q-Q Plot
qqnorm(residuals_vec,
       main = "(b) Normal Q-Q Plot",
       xlab = "Theoretical Quantiles",
       ylab = "Sample Quantiles",
       pch = 19, col = "darkblue", cex = 1.2)
qqline(residuals_vec, col = "red", lwd = 2)
grid()

par(mfrow = c(1, 1)) # Reset plot options

# ------------------------------------------------------------------------------
# Statistical Test for Normality (Shapiro-Wilk)
# ------------------------------------------------------------------------------
shapiro_res <- shapiro.test(residuals_vec)
cat(sprintf("Shapiro-Wilk Test Statistic: %.4f, p-value: %.4f\n", #nolint
            shapiro_res$statistic, shapiro_res$p.value))

# ==============================================================================
# Part 2: Simple Linear Regression on process.csv
# Question 8: Prediction & Confidence Interval for Mean Response at x0 = 400 °C
# ==============================================================================

# Load dataset
process_data <- read.csv("process.csv")
x <- process_data$temp_C
y <- process_data$hardness_HV
n <- length(x)
df_res <- n - 2

# ------------------------------------------------------------------------------
# 1. Base Calculations
# ------------------------------------------------------------------------------
x_bar <- mean(x)
y_bar <- mean(y)

Sxx <- sum((x - x_bar)^2)#nolint
Sxy <- sum((x - x_bar) * (y - y_bar))#nolint

b <- Sxy / Sxx
a <- y_bar - b * x_bar

# Residual Standard Error (s)
e <- y - (a + b * x)
s <- sqrt(sum(e^2) / df_res)

# Target Value
x0 <- 400

# ------------------------------------------------------------------------------
# 2. Point Prediction & Confidence Interval Calculation
# ------------------------------------------------------------------------------
# Point Prediction y0_hat
y0_hat <- a + b * x0

# Standard Error of Mean Response
se_y0_hat <- s * sqrt((1 / n) + ((x0 - x_bar)^2 / Sxx))

# Critical t-value (alpha = 0.05, df = 38)
t_crit <- qt(1 - 0.05 / 2, df = df_res)

# Margin of Error & Confidence Interval Bounds
margin_of_error <- t_crit * se_y0_hat
ci_lower <- y0_hat - margin_of_error
ci_upper <- y0_hat + margin_of_error

# Verification using R predict() function
ols_model <- lm(hardness_HV ~ temp_C, data = process_data)
pred_r <- predict(ols_model, newdata = data.frame(temp_C = 400), interval = "confidence", level = 0.95)#nolint

# ------------------------------------------------------------------------------
# Display Results
# ------------------------------------------------------------------------------
cat("\n==================================================================\n")
cat("    PREDICTION & CONFIDENCE INTERVAL FOR MEAN RESPONSE AT x0 = 400 °C\n")
cat("==================================================================\n")
cat(sprintf(" Target Temperature (x0)        : %d °C\n", x0))
cat(sprintf(" Point Prediction (y0_hat)     : %.4f HV\n", y0_hat))
cat("------------------------------------------------------------------\n")
cat(sprintf(" Standard Error of Mean Response: %.4f\n", se_y0_hat))
cat(sprintf(" Critical t-value (t_0.025, 38) : %.4f\n", t_crit))
cat(sprintf(" Margin of Error                : ±%.4f HV\n", margin_of_error))
cat("------------------------------------------------------------------\n")
cat(sprintf(" 95%% CI for Mean Response      : [%.4f , %.4f] HV\n", ci_lower, ci_upper))#nolint
cat("------------------------------------------------------------------\n")
cat(sprintf(" predict() Function Output     : [%.4f , %.4f] HV\n", pred_r[2], pred_r[3]))#nolint
cat(" Exact match confirmed between base formulas and R predict()!\n")
cat("==================================================================\n\n")
