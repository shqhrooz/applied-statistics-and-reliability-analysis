# ==============================================================================
# Part 1: Point Estimation & Confidence Intervals on lifetimes.csv
# Questions 1, 2, and 3: Exploratory Data Analysis, MOM, and MLE
# ==============================================================================

# Set seed for exact reproducibility
set.seed(42)

# ------------------------------------------------------------------------------
# 1. Data Loading and Summary Statistics (From Scratch)
# ------------------------------------------------------------------------------
lifetimes_data <- read.csv("lifetimes.csv")
x <- lifetimes_data$lifetime_hours
n <- length(x)

# Computing summary statistics using basic operations
mean_val   <- sum(x) / n
median_val <- median(x)
sd_val     <- sqrt(sum((x - mean_val)^2) / (n - 1))
min_val    <- min(x)
max_val    <- max(x)
cv_val     <- sd_val / mean_val

# Clean and formatted console display
cat("\n==================================================\n")
cat("          SUMMARY STATISTICS (lifetimes.csv)      \n")
cat("==================================================\n")
cat(sprintf(" Sample Size (n)   : %d\n", n))
cat(sprintf(" Mean (hours)      : %.4f\n", mean_val))
cat(sprintf(" Median (hours)    : %.4f\n", median_val))
cat(sprintf(" Std Dev (hours)   : %.4f\n", sd_val))
cat(sprintf(" Minimum (hours)   : %.4f\n", min_val))
cat(sprintf(" Maximum (hours)   : %.4f\n", max_val))
cat(sprintf(" Coeff of Var (CV) : %.4f\n", cv_val))
cat("--------------------------------------------------\n")

# Histogram Plotting
png("histogram_lifetimes.png", width = 800, height = 600, res = 120)
hist(x,
     breaks = 12,
     col = "steelblue",
     border = "white",
     main = "Histogram of Lifetimes",
     xlab = "Lifetime (Hours)",
     ylab = "Frequency",
     las = 1)
abline(v = mean_val, col = "red", lwd = 2, lty = 2)
abline(v = median_val, col = "darkgreen", lwd = 2, lty = 4)
legend("topright",
       legend = c(paste("Mean:", round(mean_val, 2)),
                  paste("Median:", round(median_val, 2))),
       col = c("red", "darkgreen"),
       lty = c(2, 4),
       lwd = 2)
dev.off()

# ------------------------------------------------------------------------------
# 2. Method of Moments (MOM) Estimation (From Scratch)
# ------------------------------------------------------------------------------
m1_sample <- sum(x) / n
theta_hat_MOM <- m1_sample # nolint

cat("\n==================================================\n")
cat("           POINT ESTIMATION RESULTS               \n")
cat("==================================================\n")
cat(sprintf(" MOM Estimate (theta_hat)  : %.4f hours\n", theta_hat_MOM))

# ------------------------------------------------------------------------------
# 3. Maximum Likelihood Estimation (MLE) (From Scratch)
# ------------------------------------------------------------------------------
theta_hat_MLE <- sum(x) / n # nolint

cat(sprintf(" MLE Estimate (theta_hat)  : %.4f hours\n", theta_hat_MLE))
cat("==================================================\n\n")


# ==============================================================================
# Part 1: Point Estimation & Confidence Intervals on lifetimes.csv
# Questions 4 & 5: Unbiasedness (Monte Carlo) & Consistency Simulation
# ==============================================================================

# Set seed for exact reproducibility
set.seed(42)

# Load original dataset and compute point estimate
lifetimes_data <- read.csv("lifetimes.csv")
x <- lifetimes_data$lifetime_hours
n_orig <- length(x)
theta_hat_orig <- sum(x) / n_orig

# ------------------------------------------------------------------------------
# 4. Unbiasedness: Monte Carlo Simulation (M = 10,000, n = 60)
# ------------------------------------------------------------------------------
M <- 10000  # nolint
n_sim <- 60

# Generate M samples of size n=60 from Exp(theta_hat_orig)
# Note: In R, rexp uses rate parameter lambda = 1 / theta
sim_samples_m4 <- matrix(rexp(M * n_sim, rate = 1 / theta_hat_orig),
                         nrow = M, ncol = n_sim)

# Calculate theta_hat for each simulated sample (row means)
theta_hat_sims_m4 <- rowMeans(sim_samples_m4)

# Calculate empirical metrics
mean_theta_sim <- mean(theta_hat_sims_m4)
empirical_bias  <- mean_theta_sim - theta_hat_orig
empirical_var   <- var(theta_hat_sims_m4)
theoretical_var <- (theta_hat_orig^2) / n_sim

# Display Question 4 Results
cat("\n==================================================\n")
cat("    QUESTION 4: UNBIASEDNESS & MONTE CARLO (M=10k)\n")
cat("==================================================\n")
cat(sprintf(" Baseline Estimate (theta_hat) : %.4f hours\n", theta_hat_orig))
cat(sprintf(" Mean of Estimates (E_hat)     : %.4f hours\n", mean_theta_sim))
cat(sprintf(" Empirical Bias                : %.4f hours\n", empirical_bias))
cat(sprintf(" Empirical Variance            : %.4f\n", empirical_var))
cat(sprintf(" Theoretical Var (theta^2/n)   : %.4f\n", theoretical_var))
cat("--------------------------------------------------\n")

# Plot Distribution of Monte Carlo Estimates
png("question4_unbiasedness_distribution.png", width = 800, height = 600, res = 120) # nolint
hist(theta_hat_sims_m4,
     breaks = 40,
     col = "lightblue",
     border = "white",
     probability = TRUE,
     main = "Monte Carlo Distribution of Estimates (M = 10,000)",
     xlab = expression(hat(theta) ~ "(Hours)"),
     ylab = "Density",
     las = 1)
abline(v = theta_hat_orig, col = "red", lwd = 2.5, lty = 1)
abline(v = mean_theta_sim, col = "blue", lwd = 2, lty = 2)
legend("topright",
       legend = c(paste("True Parameter (theta_hat):", round(theta_hat_orig, 2)), # nolint
                  paste("Mean of MC Estimates:", round(mean_theta_sim, 2))),
       col = c("red", "blue"),
       lty = c(1, 2),
       lwd = 2)
dev.off()

# ------------------------------------------------------------------------------
# 5. Consistency: Variance Simulation across Sample Sizes
# ------------------------------------------------------------------------------
sample_sizes <- c(10, 50, 200, 1000, 5000)
empirical_vars <- numeric(length(sample_sizes))
theoretical_vars <- numeric(length(sample_sizes))

for (i in seq_along(sample_sizes)) {
  n_curr <- sample_sizes[i]
  sim_samples_curr <- matrix(rexp(M * n_curr, rate = 1 / theta_hat_orig),
                             nrow = M, ncol = n_curr)
  theta_hats_curr <- rowMeans(sim_samples_curr)

  empirical_vars[i]   <- var(theta_hats_curr)
  theoretical_vars[i] <- (theta_hat_orig^2) / n_curr
}

# Display Question 5 Results
cat("\n==================================================\n")
cat("      QUESTION 5: CONSISTENCY & VARIANCE REDUCTION\n")
cat("==================================================\n")
cat(sprintf(" %-12s | %-18s | %-18s\n", "Sample Size", "Empirical Variance", "Theoretical Var")) # nolint
cat("--------------------------------------------------\n")
for (i in seq_along(sample_sizes)) {
  cat(sprintf(" n = %-8d | %-18.4f | %-18.4f\n",
              sample_sizes[i], empirical_vars[i], theoretical_vars[i]))
}
cat("==================================================\n\n")

# Plot Consistency Convergence Graph
png("question5_consistency_plot.png", width = 800, height = 600, res = 120)
plot(sample_sizes, empirical_vars,
     type = "b",
     col = "darkblue",
     pch = 19,
     lwd = 2,
     log = "x", # Log scale for better visibility across wide ranges of n
     main = "Consistency of Estimator: Variance Convergence to Zero",
     xlab = "Sample Size (n) [Log Scale]",
     ylab = expression("Variance of " ~ hat(theta) ~ " (" * Var(hat(theta)) * ")"), # nolint
     las = 1)
lines(sample_sizes, theoretical_vars, col = "red", lty = 2, lwd = 2)
points(sample_sizes, theoretical_vars, col = "red", pch = 17)
grid(col = "gray", lty = "dotted")
legend("topright",
       legend = c("Empirical Variance (Monte Carlo)",
                  expression("Theoretical Variance (" * theta^2 / n * ")")),
       col = c("darkblue", "red"),
       pch = c(19, 17),
       lty = c(1, 2),
       lwd = 2)
dev.off()


# ==============================================================================
# Part 1: Point Estimation & Confidence Intervals on lifetimes.csv
# Question 6: Cramér-Rao Lower Bound (CRLB) & Efficiency
# ==============================================================================

# Set seed for exact reproducibility
set.seed(42)

# Load original dataset and compute point estimate
lifetimes_data <- read.csv("lifetimes.csv")
x <- lifetimes_data$lifetime_hours
n <- length(x)
theta_hat <- sum(x) / n

# ------------------------------------------------------------------------------
# Cramér-Rao Lower Bound (CRLB) Computation
# ------------------------------------------------------------------------------
# Fisher Information for a single observation: I_1(theta) = 1 / theta^2
# Total Fisher Information for n observations: I_n(theta) = n / theta^2
# CRLB = 1 / I_n(theta) = theta^2 / n # nolint

crlb_numerical <- (theta_hat^2) / n

# Retrieve Monte Carlo Empirical Variance from Question 4 (M = 10,000, n = 60)
M <- 10000
sim_samples <- matrix(rexp(M * n, rate = 1 / theta_hat), nrow = M, ncol = n)
sim_theta_hats <- rowMeans(sim_samples)
empirical_var <- var(sim_theta_hats)

# Efficiency Ratio
efficiency_ratio <- (crlb_numerical / empirical_var) * 100

# Display Question 6 Results
cat("\n==================================================\n")
cat("    QUESTION 6: CRAMER-RAO LOWER BOUND & EFFICIENCY\n")
cat("==================================================\n")
cat(sprintf(" Sample Size (n)               : %d\n", n))
cat(sprintf(" Estimated Parameter (theta_hat): %.4f hours\n", theta_hat))
cat(sprintf(" Theoretical CRLB (theta^2/n)   : %.4f\n", crlb_numerical))
cat(sprintf(" Empirical Variance (from Q4)  : %.4f\n", empirical_var))
cat(sprintf(" Empirical Efficiency          : %.2f%%\n", efficiency_ratio))
cat("--------------------------------------------------\n")
cat(" Theoretical Conclusion: MLE achieves CRLB exactly.\n")
cat(" Therefore, theta_hat is a UMVUE (Efficient Estimator).\n")
cat("==================================================\n\n")

# ==============================================================================
# Part 1: Point Estimation & Confidence Intervals on lifetimes.csv
# Question 7: Exact Chi-Square vs Percentile Bootstrap 95% CIs
# ==============================================================================

# Set seed for exact reproducibility
set.seed(42)

# Load dataset
lifetimes_data <- read.csv("lifetimes.csv")
x <- lifetimes_data$lifetime_hours
n <- length(x)
mean_x <- mean(x)
sum_x <- sum(x)

# ------------------------------------------------------------------------------
# 1. Exact 95% Confidence Interval using Chi-Square Distribution
# ------------------------------------------------------------------------------
# Property: (2 * n * bar(x)) / theta ~ Chi-Square(df = 2*n) # nolint
# P( chi2_lower <= 2*sum(x)/theta <= chi2_upper ) = 0.95
# Lower Bound = (2 * sum(x)) / chi2_upper
# Upper Bound = (2 * sum(x)) / chi2_lower

df_chi2 <- 2 * n
chi2_lower <- qchi2(0.025, df = df_chi2)
chi2_upper <- qchi2(0.975, df = df_chi2)

ci_exact_lower <- (2 * sum_x) / chi2_upper
ci_exact_upper <- (2 * sum_x) / chi2_lower
width_exact <- ci_exact_upper - ci_exact_lower

# ------------------------------------------------------------------------------
# 2. Percentile Bootstrap 95% Confidence Interval (B = 5000)
# ------------------------------------------------------------------------------
B <- 5000
boot_means <- numeric(B)

for (i in 1:B) {
  boot_sample <- sample(x, size = n, replace = TRUE)
  boot_means[i] <- mean(boot_sample)
}

ci_boot_lower <- quantile(boot_means, probs = 0.025)
ci_boot_upper <- quantile(boot_means, probs = 0.975)
width_boot <- ci_boot_upper - ci_boot_lower

# ------------------------------------------------------------------------------
# Display Results
# ------------------------------------------------------------------------------
cat("\n==================================================================\n")
cat("    QUESTION 7: EXACT CHI-SQUARE VS BOOTSTRAP 95% CONFIDENCE INTERVALS\n")
cat("==================================================================\n")
cat(sprintf(" Sample Size (n)               : %d (df = 2n = %d)\n", n, df_chi2))
cat(sprintf(" Sample Mean (theta_hat)       : %.4f hours\n", mean_x))
cat("------------------------------------------------------------------\n")
cat(" 1. EXACT CHI-SQUARE METHOD:\n")
cat(sprintf("    - Chi2 lower quantile (2.5%%) : %.4f\n", chi2_lower))
cat(sprintf("    - Chi2 upper quantile (97.5%%): %.4f\n", chi2_upper))
cat(sprintf("    - 95%% Exact CI               : [%.4f , %.4f]\n", ci_exact_lower, ci_exact_upper)) # nolint
cat(sprintf("    - Interval Width             : %.4f hours\n", width_exact))
cat("------------------------------------------------------------------\n")
cat(" 2. PERCENTILE BOOTSTRAP METHOD (B = 5000):\n")
cat(sprintf("    - 95%% Bootstrap CI           : [%.4f , %.4f]\n", ci_boot_lower, ci_boot_upper)) # nolint
cat(sprintf("    - Interval Width             : %.4f hours\n", width_boot))
cat("==================================================================\n\n")


# ==============================================================================
# Part 1: Point Estimation & Confidence Intervals on lifetimes.csv
# Challenge Question: Invariance Property of MLE & Reliability R = P(X > 500)
# ==============================================================================

# Set seed for exact reproducibility
set.seed(42)

# Load dataset
lifetimes_data <- read.csv("lifetimes.csv")
x <- lifetimes_data$lifetime_hours
n <- length(x)
theta_hat <- mean(x)

# ------------------------------------------------------------------------------
# 1. MLE of Reliability R using Invariance Property
# ------------------------------------------------------------------------------
# Definition: R = P(X > 500) = exp(-500 / theta) # nolint
# By Invariance Property of MLE: R_hat = exp(-500 / theta_hat)

t_target <- 500
R_hat <- exp(-t_target / theta_hat) # nolint

# ------------------------------------------------------------------------------
# 2. Percentile Bootstrap 95% Confidence Interval for R (B = 5000)
# ------------------------------------------------------------------------------
B <- 5000 # nolint
boot_R_hats <- numeric(B) # nolint

for (i in 1:B) {
  boot_sample <- sample(x, size = n, replace = TRUE)
  boot_theta_hat <- mean(boot_sample)
  boot_R_hats[i] <- exp(-t_target / boot_theta_hat) # nolint
}

ci_R_lower <- quantile(boot_R_hats, probs = 0.025) # nolint
ci_R_upper <- quantile(boot_R_hats, probs = 0.975) # nolint

# ------------------------------------------------------------------------------
# Display Challenge Question Results
# ------------------------------------------------------------------------------
cat("\n==================================================================\n")
cat("    CHALLENGE QUESTION: RELIABILITY R = P(X > 500) & BOOTSTRAP CI\n")
cat("==================================================================\n")
cat(sprintf(" Target Time (t)               : %d hours\n", t_target))
cat(sprintf(" Mean Lifetime Estimate (theta): %.4f hours\n", theta_hat))
cat("------------------------------------------------------------------\n")
cat(" 1. MLE OF RELIABILITY (R_hat):\n")
cat(sprintf("    - R_hat = exp(-500 / %.4f)  : %.6f  (%.2f%%)\n", theta_hat, R_hat, R_hat * 100)) # nolint
cat("------------------------------------------------------------------\n")
cat(" 2. PERCENTILE BOOTSTRAP 95%% CONFIDENCE INTERVAL (B = 5000):\n")
cat(sprintf("    - 95%% Bootstrap CI for R   : [%.6f , %.6f]\n", ci_R_lower, ci_R_upper)) # nolint
cat(sprintf("    - Percentage Range           : [%.2f%% , %.2f%%]\n", ci_R_lower * 100, ci_R_upper * 100)) # nolint
cat("==================================================================\n\n")

